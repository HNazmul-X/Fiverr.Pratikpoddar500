/* navbar toggling javscript here */
const NavbarContent = document.querySelector(".hnazmul-navbar .hnazmul-navbar-container .hnazmul-navbar-content");
const navbarToggleIcon = document.querySelector(".hnazmul-navbar .hnazmul-navbar-container .hnazmul-nav-toggle-btn");
const navbarCloserIcon = document.querySelector(".hnazmul-navbar .hnazmul-navbar-container .hnazmul-navbar-content .hnazmul-navbar-content-wrapper button.navbar-closer-icon");

navbarToggleIcon.addEventListener("click", () => {
    NavbarContent.classList.toggle("navbar-show");
});
navbarCloserIcon.addEventListener("click", () => {
    NavbarContent.classList.toggle("navbar-show");
});

/* use profile toogleer */
const userToogleIcon = document.querySelector("header#header-part nav.navbar #navbarNav .nav-item .nav-link.user-toogle-area .user-toggle-icon");
const userToggleContent = document.querySelector("header#header-part nav.navbar #navbarNav .nav-item .nav-link.user-toogle-area .toggle-content");
let x = true;
userToogleIcon.addEventListener("click", () => {
    if(x){
        userToggleContent.classList.add("content-show");
        x = !x
    } else{
        userToggleContent.classList.remove("content-show");
        x = !x
    }
})